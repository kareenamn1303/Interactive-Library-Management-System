<style>
	.wrapper{
		background-image: url({{  asset("images/library.jpg")}});
		background-color: #cccccc;
		height: 500px;
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		position: relative;
	}

    .wrapper1{
		background-image: url({{ asset('images/books.jpg') }});
		background-color: #cccccc;
		height: 500px;
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		position: relative;
	}

</style>